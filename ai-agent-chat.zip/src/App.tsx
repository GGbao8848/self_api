/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { Settings, Send, Bot, User, Wrench, XCircle, CheckCircle2, ChevronDown, ChevronRight, Loader2, Menu, MessageSquare, Plus, PanelLeft, PanelRight } from 'lucide-react';

interface ToolDef {
  name: string;
  description: string;
  parameters: any;
}

interface ToolCall {
  id: string;
  name: string;
  arguments: any;
  result: any;
  error: string | null;
}

interface Message {
  role: 'user' | 'model';
  text?: string;
  toolCalls?: ToolCall[];
}

interface SessionItem {
  id: string;
  messageCount: number;
  preview: string;
}

export default function App() {
  const [sessionId, setSessionId] = useState<string>(() => {
    return localStorage.getItem('agent_session_id') || uuidv4();
  });
  const [sessions, setSessions] = useState<SessionItem[]>([]);
  const [tools, setTools] = useState<ToolDef[]>([]);
  const [history, setHistory] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [leftSidebarOpen, setLeftSidebarOpen] = useState(true);
  const [rightSidebarOpen, setRightSidebarOpen] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    localStorage.setItem('agent_session_id', sessionId);
    fetchTools();
    fetchHistory();
  }, [sessionId]);

  useEffect(() => {
    fetchSessions();
  }, [sessionId, history]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history, loading]);

  const fetchSessions = async () => {
    try {
      const res = await fetch('/api/v1/agent/sessions');
      const data = await res.json();
      setSessions(data);
    } catch (e) {
      console.error('Failed to fetch sessions:', e);
    }
  };

  const fetchTools = async () => {
    try {
      const res = await fetch('/api/v1/agent/tools');
      const data = await res.json();
      setTools(data);
    } catch (e) {
      console.error('Failed to fetch tools:', e);
    }
  };

  const fetchHistory = async () => {
    try {
      const res = await fetch(`/api/v1/agent/sessions/${sessionId}`);
      const data = await res.json();
      if (data.history) {
        setHistory(data.history);
      }
    } catch (e) {
      console.error('Failed to fetch history:', e);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userMessage: Message = { role: 'user', text: input };
    setHistory((prev) => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/v1/agent/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ session_id: sessionId, message: input }),
      });
      const data: Message = await res.json();
      setHistory((prev) => [...prev, data]);
    } catch (e) {
      console.error('Chat error:', e);
      setHistory((prev) => [
        ...prev,
        { role: 'model', text: 'An error occurred while processing your request.' },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const resetSession = () => {
    setSessionId(uuidv4());
    setHistory([]);
  };

  return (
    <div className="flex h-screen bg-gray-50 text-gray-900 font-sans overflow-hidden">
      {/* Left Sidebar: Session History */}
      <aside
        className={`${
          leftSidebarOpen ? 'translate-x-0 w-64' : '-translate-x-full w-0'
        } flex-shrink-0 bg-white border-r border-gray-200 transition-all duration-300 ease-in-out flex flex-col`}
      >
        <div className="p-4 border-b border-gray-200 flex justify-between items-center bg-gray-50/50 h-[69px]">
          <div className="flex items-center gap-2 font-semibold">
            <MessageSquare className="w-5 h-5 text-indigo-600" />
            <span>Chat History</span>
          </div>
          <button
            onClick={() => setLeftSidebarOpen(false)}
            className="md:hidden text-gray-500 hover:text-gray-700"
          >
            <XCircle className="w-5 h-5" />
          </button>
        </div>
        
        <div className="p-4 overflow-y-auto flex-1 space-y-2">
          <button
            onClick={resetSession}
            className="w-full flex items-center gap-2 px-3 py-2 bg-indigo-50 text-indigo-700 rounded-md hover:bg-indigo-100 transition-colors border border-indigo-100 mb-4"
          >
            <Plus className="w-4 h-4" />
            <span className="font-medium text-sm">New Chat</span>
          </button>
          
          <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">
            Recent Sessions
          </h3>
          
          <div className="space-y-1">
            {sessions.map((sess) => (
              <button
                key={sess.id}
                onClick={() => setSessionId(sess.id)}
                className={`w-full text-left px-3 py-2.5 rounded-md text-sm transition-colors flex flex-col gap-1 ${
                  sess.id === sessionId 
                    ? 'bg-indigo-600 text-white shadow-sm' 
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <span className="font-medium truncate block capitalize w-full">
                  {sess.preview}
                </span>
                <span className={`text-xs ${sess.id === sessionId ? 'text-indigo-200' : 'text-gray-400'}`}>
                  {sess.messageCount} messages
                </span>
              </button>
            ))}
            {sessions.length === 0 && (
              <div className="text-sm text-gray-500 text-center py-4">No past sessions</div>
            )}
          </div>
        </div>
      </aside>

      {/* Main Chat Area */}
      <main className="flex-1 flex flex-col h-full min-w-0 bg-gray-50">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 p-4 py-3 flex items-center justify-between z-10 shadow-sm h-[69px]">
          <div className="flex items-center gap-3">
            {!leftSidebarOpen && (
              <button
                onClick={() => setLeftSidebarOpen(true)}
                className="p-1.5 text-gray-500 hover:bg-gray-100 rounded-md"
                title="Toggle Session History"
              >
                <PanelLeft className="w-5 h-5" />
              </button>
            )}
            <h1 className="font-semibold text-lg flex items-center gap-2">
              <Bot className="w-6 h-6 text-indigo-600" />
              AI Assistant
            </h1>
          </div>
          <div className="flex items-center gap-3 text-sm">
            <div className="hidden sm:flex items-center gap-2 px-3 py-1 bg-gray-100 rounded-full border border-gray-200">
              <span className="w-2 h-2 rounded-full bg-green-500"></span>
              <span className="font-mono text-xs text-gray-600" title="Session ID">
                {sessionId.split('-')[0]}...
              </span>
            </div>
            {!rightSidebarOpen && (
              <button
                onClick={() => setRightSidebarOpen(true)}
                className="p-1.5 text-gray-500 hover:bg-gray-100 rounded-md"
                title="Toggle Capabilities"
              >
                <PanelRight className="w-5 h-5" />
              </button>
            )}
          </div>
        </header>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          {history.length === 0 && (
            <div className="text-center text-gray-500 mt-20">
              <Bot className="w-16 h-16 mx-auto mb-4 text-indigo-200" />
              <h2 className="text-xl font-medium text-gray-700 mb-2">How can I help you?</h2>
              <p className="max-w-md mx-auto text-sm">
                I am an AI agent equipped with external tools. Ask me a question and I can retrieve weather, time, and more!
              </p>
            </div>
          )}

          {history.map((msg, idx) => (
            <div
              key={idx}
              className={`flex gap-4 max-w-4xl mx-auto w-full ${
                msg.role === 'user' ? 'flex-row-reverse' : ''
              }`}
            >
              <div
                className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
                  msg.role === 'user' ? 'bg-indigo-600' : 'bg-gray-800'
                }`}
              >
                {msg.role === 'user' ? (
                  <User className="w-5 h-5 text-white" />
                ) : (
                  <Bot className="w-5 h-5 text-white" />
                )}
              </div>

              <div
                className={`flex-1 space-y-3 ${
                  msg.role === 'user' ? 'flex flex-col items-end' : ''
                }`}
              >
                {/* Text content */}
                {msg.text && (
                  <div
                    className={`px-4 py-3 rounded-2xl shadow-sm text-[15px] leading-relaxed max-w-[85%] ${
                      msg.role === 'user'
                        ? 'bg-indigo-600 text-white rounded-tr-sm'
                        : 'bg-white border border-gray-200 text-gray-800 rounded-tl-sm'
                    }`}
                  >
                    {msg.text}
                  </div>
                )}

                {/* Tool calls UI */}
                {msg.toolCalls && msg.toolCalls.length > 0 && (
                  <div className="space-y-2 mt-2 max-w-[85%] w-full">
                    {msg.toolCalls.map((call, cidx) => (
                      <ToolCallCard key={cidx} call={call} />
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex gap-4 max-w-4xl mx-auto w-full">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center">
                <Bot className="w-5 h-5 text-white animate-pulse" />
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-500">
                <Loader2 className="w-4 h-4 animate-spin text-indigo-500" />
                Thinking & working...
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="bg-white border-t border-gray-200 p-4">
          <form
            onSubmit={handleSubmit}
            className="max-w-4xl mx-auto flex items-end gap-3 w-full"
          >
            <div className="relative flex-1">
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    if (!loading && input.trim()) handleSubmit(e);
                  }
                }}
                placeholder="Message the agent... (Press Enter to send)"
                className="w-full bg-gray-50 border border-gray-300 rounded-xl py-3 pl-4 pr-12 outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 resize-none max-h-32 shadow-sm transition-shadow"
                rows={1}
                disabled={loading}
                style={{
                  minHeight: '48px',
                  height: input ? 'auto' : '48px',
                }}
              />
              <button
                type="submit"
                disabled={!input.trim() || loading}
                className="absolute right-2 bottom-2 p-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50 disabled:hover:bg-indigo-600 transition-colors"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </form>
          <div className="text-center mt-2 text-xs text-gray-400">
            AI can make mistakes. Check important info.
          </div>
        </div>
      </main>

      {/* Right Sidebar: Capabilities */}
      <aside
        className={`${
          rightSidebarOpen ? 'translate-x-0 w-80' : 'translate-x-full w-0'
        } flex-shrink-0 bg-white border-l border-gray-200 transition-all duration-300 ease-in-out flex flex-col`}
      >
        <div className="p-4 border-b border-gray-200 flex justify-between items-center bg-gray-50/50 h-[69px]">
          <div className="flex items-center gap-2 font-semibold">
            <Settings className="w-5 h-5 text-indigo-600" />
            <span>Agent Capabilities</span>
          </div>
          <button
            onClick={() => setRightSidebarOpen(false)}
            className="text-gray-500 hover:text-gray-700"
          >
            <XCircle className="w-5 h-5" />
          </button>
        </div>
        
        <div className="p-4 overflow-y-auto flex-1">
          <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-4">
            Available Tools ({tools.length})
          </h3>
          <div className="space-y-4">
            {tools.map((tool, idx) => (
              <div key={idx} className="bg-gray-50 rounded-lg p-3 border border-gray-200">
                <div className="flex items-start gap-2 mb-2">
                  <Wrench className="w-4 h-4 text-indigo-500 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-sm">{tool.name}</h4>
                    <p className="text-xs text-gray-600 mt-1">{tool.description}</p>
                  </div>
                </div>
                <div className="mt-3">
                  <p className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-1">
                    Parameters
                  </p>
                  <pre className="text-[11px] bg-white p-2 rounded border border-gray-100 overflow-x-auto text-gray-700">
                    {JSON.stringify(tool.parameters.properties, null, 2)}
                  </pre>
                </div>
              </div>
            ))}
          </div>
        </div>
      </aside>
    </div>
  );
}

function ToolCallCard({ call }: { call: ToolCall }) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div className="bg-white border text-sm max-w-full font-mono rounded-lg overflow-hidden shadow-sm transition-all duration-200 ease-in-out border-gray-200">
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center justify-between p-3 bg-gray-50 hover:bg-gray-100 transition-colors text-left"
      >
        <div className="flex items-center gap-2">
          {call.error ? (
            <XCircle className="w-4 h-4 text-red-500" />
          ) : (
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          )}
          <span className="font-semibold text-gray-700">call: {call.name}</span>
          {!expanded && (
            <span className="text-xs text-gray-500 truncate ml-2 max-w-[150px] sm:max-w-xs">
              {JSON.stringify(call.arguments)}
            </span>
          )}
        </div>
        {expanded ? (
          <ChevronDown className="w-4 h-4 text-gray-400" />
        ) : (
          <ChevronRight className="w-4 h-4 text-gray-400" />
        )}
      </button>

      {expanded && (
        <div className="p-3 border-t border-gray-100 bg-white space-y-3">
          <div>
            <span className="text-[10px] text-gray-400 uppercase tracking-widest font-semibold block mb-1">
              Arguments
            </span>
            <pre className="text-xs text-gray-800 bg-gray-50 p-2 rounded whitespace-pre-wrap word-break">
              {JSON.stringify(call.arguments, null, 2)}
            </pre>
          </div>

          <div>
            <span className="text-[10px] text-gray-400 uppercase tracking-widest font-semibold block mb-1">
              Result
            </span>
            {call.error ? (
              <pre className="text-xs text-red-600 bg-red-50 p-2 rounded whitespace-pre-wrap word-break">
                {call.error}
              </pre>
            ) : (
              <pre className="text-xs text-emerald-700 bg-emerald-50 p-2 rounded whitespace-pre-wrap word-break">
                {JSON.stringify(call.result, null, 2)}
              </pre>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
